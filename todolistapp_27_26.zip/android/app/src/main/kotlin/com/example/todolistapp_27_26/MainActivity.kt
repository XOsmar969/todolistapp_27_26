package com.example.todolistapp_27_26

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
