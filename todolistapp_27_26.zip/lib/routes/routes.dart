class AppRoutes {
  static const String login = '/login';
  static const String dashboard = '/dashboard';
  static const String addTodo = '/add_todo';
  static const String home = '/todo';
  static const String auth = '/auth';
  static const String splashscreen = '/splashscreen';
}
